import re
import docx as python_docx
import fitz
import tkinter as tk
from tkinter import filedialog, messagebox
import time

name_pattern = r'[A-Z][a-z]+\s[A-Z]\.\s[A-Z][a-z]+'
email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
phone_pattern = r'\(\+63\)\s9\d{2}-\d{3}-\d{4}'

def extract_names(resume):
    matches = re.findall(name_pattern, resume)
    names = [name.strip() for name in matches]
    return names

def extract_contact_details(resume):
    emails = re.findall(email_pattern, resume)
    phones = re.findall(phone_pattern, resume)
    return emails, phones

def extract_details_from_docx(resumes_file):
    extracted_details = []
    doc = python_docx.Document(resumes_file)

    for paragraph in doc.paragraphs:
        text = paragraph.text.strip()
        names = extract_names(text)
        extracted_details.extend(names)

        emails, phones = extract_contact_details(text)
        extracted_details.extend(emails)
        extracted_details.extend(phones)

    return extracted_details

def extract_details_from_txt(resumes_file):
    extracted_details = []
    with open(resumes_file, 'r') as file:
        resumes = file.readlines()
    for resume in resumes:
        names = extract_names(resume)
        extracted_details.extend(names)
        emails, phones = extract_contact_details(resume)
        extracted_details.extend(emails)
        extracted_details.extend(phones)
    return extracted_details

def extract_details_from_pdf(resumes_file):
    extracted_details = []
    with fitz.open(resumes_file) as doc:
        for page in doc:
            text = page.get_text()

            # Split the text into separate blocks for each candidate
            blocks = re.split(r'\n(?=[A-Z][a-z]+\s[A-Z]\.\s[A-Z][a-z]*)', text)

            for block in blocks:
                # Extract names
                names = extract_names(block)
                names = [name for name in names if re.match(name_pattern, name)]
                extracted_details.extend(names)

                # Extract emails and phones
                emails, phones = extract_contact_details(block)
                emails = [email for email in emails if re.match(email_pattern, email)]
                phones = [phone for phone in phones if re.match(phone_pattern, phone)]
                extracted_details.extend(emails)
                extracted_details.extend(phones)

    return extracted_details

def browse_file():
    global file_path_entry
    file_path = filedialog.askopenfilename()
    file_path_entry.delete(0, tk.END)
    file_path_entry.insert(0, file_path)

def extract_details():
    global file_path_entry, file_type_var, details_text

    file_path = file_path_entry.get()
    file_type = file_type_var.get()

    if file_path == "":
        messagebox.showerror("Error", "Please select a file to extract details from.")
        return

    if file_type == "":
        messagebox.showerror("Error", "Please select a file type.")
        return

    try:
        start_time = time.monotonic()  # start timer
        if file_type == 'docx':
            extracted_details = extract_details_from_docx(file_path)
        elif file_type == 'txt':
            extracted_details = extract_details_from_txt(file_path)
        elif file_type == 'pdf':
            extracted_details = extract_details_from_pdf(file_path)
        elapsed_time = time.monotonic() - start_time  # calculate elapsed time

        details_text.delete('1.0', tk.END)
        details_text.insert(tk.END, "\n".join(extracted_details))
        details_text.insert(tk.END, f"\n\nExtraction completed in {elapsed_time:.2f} seconds.")  # print elapsed time

        # Add a scrollbar to the details_text widget
        scrollbar = tk.Scrollbar(root, command=details_text.yview)
        scrollbar.grid(row=2, column=2, sticky='ns')
        details_text['yscrollcommand'] = scrollbar.set

    except FileNotFoundError:
        messagebox.showerror("Error", "The file does not exist.")
    except Exception as e:
        messagebox.showerror("Error", "Wrong file type selected or invalid file.\n\n" + str(e))

root = tk.Tk()
root.title("Resume Parser")

# create a label for file type
file_type_label = tk.Label(root, text="Select the type of file to read:")
file_type_label.grid(row=0, column=0, padx=10, pady=10)

# create a dropdown menu for file type
file_type_options = ["docx", "txt", "pdf"]
file_type_var = tk.StringVar(value=file_type_options[0])
file_type_dropdown = tk.OptionMenu(root, file_type_var, *file_type_options)
file_type_dropdown.grid(row=0, column=1, padx=10, pady=10)

# create a label for file path
file_path_label = tk.Label(root, text="Enter the path to the file to read:")
file_path_label.grid(row=1, column=0, padx=10, pady=10)

# create a text field for file path
file_path_entry = tk.Entry(root, width=50)
file_path_entry.insert(0, "File path")
file_path_entry.bind("<FocusIn>", lambda args: file_path_entry.delete('0', 'end') if file_path_entry.get() == "File path" else None)
file_path_entry.grid(row=1, column=1, padx=10, pady=10)

# create a button to browse for the file
browse_button = tk.Button(root, text="Browse", command=browse_file)
browse_button.grid(row=1, column=2, padx=10, pady=10)

# create a button to parse the file
parse_button = tk.Button(root, text="Parse", command=extract_details)
parse_button.grid(row=2, column=0, columnspan=3, padx=10, pady=10)

# create a label for the extracted details
details_label = tk.Label(root, text="Extracted Details:")
details_label.grid(row=3, column=0, padx=10, pady=10)

details_text_frame = tk.Frame(root)
details_text_frame.grid(row=3, column=0, columnspan=2, padx=10, pady=10)

details_text_scrollbar = tk.Scrollbar(details_text_frame)
details_text_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

details_text = tk.Text(details_text_frame, yscrollcommand=details_text_scrollbar.set, wrap=tk.WORD)
details_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

details_text_scrollbar.config(command=details_text.yview)

root.mainloop()